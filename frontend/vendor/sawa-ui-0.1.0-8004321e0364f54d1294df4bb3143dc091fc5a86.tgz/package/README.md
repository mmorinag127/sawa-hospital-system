# @sawa/ui 0.1.0

Thin MUI, React Hook Form and TanStack Query controls. Consumers retain their
existing Next routes, navigation, authentication, API client and business fields.
No CRUD engine, provider protocol, router, decoder, token store or domain schema.

Exports: `SawaProvider`, `sawaTheme`, `SearchBar`, `DataTable`, `RequestState`,
`EditForm`, `FormTextField` and their prop types. The provider uses a required
non-secret `sessionKey`; change it on account/authorization changes to discard
old queries and remount forms. Use `useQueryClient()` to explicitly clear/invalidate
the current cache. Request cancellation requires consumer query functions to use
TanStack Query's AbortSignal. Authentication and navigation remain consumer-owned.

```tsx
<SawaProvider sessionKey={sessionGeneration}>
  <EditForm key={record.id} label="編集" defaultValues={record}
    onSave={saveAndReturnStoredValues} onReload={fetchStoredValues}
    classifyError={classifyApiError} onDirtyChange={setDirty}>
    <FormTextField name="name" label="名前" rules={{ required: "必須です" }} />
  </EditForm>
</SawaProvider>
```

`EditForm` takes initial values only. Key/mount each record separately; confirm
dirty changes before switching records or using Next navigation. Background
refetch never replaces operator edits. Saves are pessimistic, disable fields
while pending, retain values on failure and reset only to returned saved values.
`classifyError` returns `{kind: 'conflict' | 'error', message: string}`. Conflicts
block save until explicit reload succeeds; dirty reload first confirms discard.
Consumers must return the saved revision along with all form values and retain
server field/validation semantics. Existing delete/bulk operations are not added.

`FormTextField` forwards standard MUI TextField props; use `select` with consumer
MenuItem children for options. Use explicit `parseValue`/`formatValue` for nullable
numbers or arrays. Zero/null/empty-string distinctions belong to the consumer.
Use the same exact RHF/Query/MUI versions as this package when importing their
hooks/components directly, so form/query context stays shared.
The common theme disables floating-label transitions: rapidly entered values must
not overlap a label while it moves. Labels remain visible and associated with inputs.

```sh
npm ci --ignore-scripts --cache ./tmp/npm-cache
npm run typecheck
npm run build
npm test
npm run test:consumer
npm run test:webkit
```

Run using the production-compatible Node runtime; consumer fixture is Next
16.3.8 / React 18.3.1, with Node >=20.9 required by Next. WebKit tests are offline
fixtures with synthetic composition events, not OS IME or actual product tests.
The fixture does not prove Next SSR/hydration or the hospital page heading. Input
label/value rectangles are checked in focused, blurred, filled and empty states.
Node 20.17.0 is the available tested patch, not a claim about latest Node 20.
The esbuild dependency is only for this offline browser test; production builds
use tsc and emit native ESM plus declarations. Cache/output stay in this WT's tmp.

Temporary pack tests install dist and declarations into an isolated consumer.
Parent commits source before producing the release pack pinned to source SHA and
artifact hash/integrity. Integration, stg and user acceptance remain open.
